from __future__ import absolute_import, division, print_function
import numpy as np
import rospy
from scipy.spatial import cKDTree


def icp(x, y, num_iters=10, inlier_ratio=1.0, inlier_dist_mult=1.0, tol=1e-9, y_index=None, R=None, t=None):
    """Iterative closest point algorithm, minimizing sum of squares of point to point distances.

    :param x: Points to align, D-by-N matrix.
    :param y: Reference points to align to, such that y[:, j] ~ R * x[:, i] + t for corresponding pair (i, j).
    :param num_iters: Number of iterations, consisting of NN search and transform update.
    :param inlier_ratio: Ratio of nearest points from which to compute inlier distance.
    :param inlier_dist_mult: Inlier distance multiplier deciding what is included in optimization.
    :param tol: Minimum improvement per iteration to continue.
    :param y_index: Index for NN search for y (cKDTree).
    :param R: Initial rotation.
    :param t: Initial translation.
    :return: Optimized rotation R, translation t, and corresponding criterion value on inliers (including multiplier).
    """
    assert x.shape[0] == y.shape[0]
    if y_index is None:
        y_index = cKDTree(y.T)
    if R is None:
        R = np.eye(x.shape[0])
    if t is None:
        t = np.zeros((x.shape[0], 1))
    prev_err_inl = float('inf')
    
    # TODO: Implement!
    err_inl = float('inf')
    return R, t, err_inl
